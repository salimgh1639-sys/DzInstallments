import { Text, View } from 'react-native';
export default function App(){return <View><Text>DzInstallments SDK54</Text></View>;}