
import React, { useState, useEffect } from 'react';
import { Order, OrderStatus, User, Product, MediaType } from '../types';
import { TrendingUp, Users, ShoppingBag, Clock, CheckCircle, XCircle, Search, LayoutDashboard, FileCheck, Menu, X, ArrowLeft, Calendar, UserPlus, AlertCircle, Lock, User as UserIcon, Phone, Mail, MapPin, CreditCard, FileText, Upload, Eye, FolderOpen, FolderCheck, Truck, PackageCheck, History, CalendarDays, Copy, Send, Circle, Archive, Printer, Gift, ZoomIn, Briefcase, Hash, Wallet, BarChart3, ListFilter, Bell, Plus, Image } from 'lucide-react';
import { ALGERIA_WILAYAS, DELIVERY_COMPANIES } from '../constants';
import Button from './Button';

interface AdminDashboardProps {
  orders: Order[];
  users?: User[];
  onUpdateStatus: (orderId: string, status: OrderStatus, reason?: string, deliveryData?: { deliveryCompany: string, trackingNumber: string }) => void;
  onAddUser?: (user: User) => void;
  onAddProduct?: (product: Product) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ orders, users = [], onUpdateStatus, onAddUser, onAddProduct }) => {
  const activeViewInitial = localStorage.getItem('dz_admin_view') as 'dashboard' | 'approvals' | 'customers' || 'dashboard';
  const [activeView, setActiveView] = useState<'dashboard' | 'approvals' | 'customers'>(activeViewInitial);
  
  // Updated state to include 'final'
  const [activeApprovalTab, setActiveApprovalTab] = useState<'all_transactions' | 'preliminary' | 'waiting_files' | 'ready_shipping' | 'shipped' | 'final'>('all_transactions');
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Shipping Inputs State for Ready Shipping Tab
  const [shippingUpdates, setShippingUpdates] = useState<Record<string, { company: string, tracking: string }>>({});
  const [shippingErrors, setShippingErrors] = useState<Record<string, boolean>>({});

  // Add Customer Modal State
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);

  // New Product State
  const initialProductState = {
     name: '', brand: '', category: '', description: '', totalPrice: '', months: '12', features: '', imageUrl: ''
  };
  const [newProduct, setNewProduct] = useState(initialProductState);
  
  // Order Details Modal State
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<User | null>(null);
  
  // Image Preview Modal State
  const [viewImage, setViewImage] = useState<{ url: string, title: string } | null>(null);
  
  // Rejection Modal State
  const [rejectModal, setRejectModal] = useState<{ show: boolean, orderId: string | null }>({ show: false, orderId: null });
  const [rejectionReason, setRejectionReason] = useState('');

  // Receipt Confirmation Modal State
  const [confirmReceiptModal, setConfirmReceiptModal] = useState<{ show: boolean, order: Order | null }>({ show: false, order: null });

  // Copy Feedback State
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Delivery Updates Notification State
  const [deliveryUpdates, setDeliveryUpdates] = useState<string[]>([]);
  const [showUpdateToast, setShowUpdateToast] = useState(false);

  const [fieldWarning, setFieldWarning] = useState<{field: string, msg: string} | null>(null);
  const [error, setError] = useState('');
  
  const initialFormState = {
    firstName: '', lastName: '', birthDate: '', phone1: '', phone2: '', email: '', password: '', confirmPassword: '',
    wilaya: ALGERIA_WILAYAS[0], baladyia: '', address: '', ccpNumber: '', ccpKey: '', nin: '', ninExpiry: ''
  };
  const [formData, setFormData] = useState<User & { password: string; confirmPassword: string }>(initialFormState);
  
  const [files, setFiles] = useState<{
    idCardFront: File | null;
    idCardBack: File | null;
    chequeImage: File | null;
    accountStatement: File | null;
  }>({
    idCardFront: null,
    idCardBack: null,
    chequeImage: null,
    accountStatement: null,
  });

  // Load delivery updates on mount and when orders change
  useEffect(() => {
    try {
        const storedUpdates = JSON.parse(localStorage.getItem('dz_admin_delivery_updates') || '[]');
        setDeliveryUpdates(storedUpdates);
        
        if (storedUpdates.length > 0) {
            setShowUpdateToast(true);
            setTimeout(() => setShowUpdateToast(false), 5000);
        }
    } catch (e) {
        console.error("Error loading delivery updates");
    }
  }, [orders]);

  const clearDeliveryUpdate = (orderId: string) => {
    const updated = deliveryUpdates.filter(id => id !== orderId);
    setDeliveryUpdates(updated);
    localStorage.setItem('dz_admin_delivery_updates', JSON.stringify(updated));
  };

  // Calculate Stats
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.status === OrderStatus.PENDING).length;
  const waitingFilesOrdersCount = orders.filter(o => o.status === OrderStatus.WAITING_FOR_FILES).length;
  const readyShippingOrdersCount = orders.filter(o => o.status === OrderStatus.READY_FOR_SHIPPING).length;
  const shippedOrdersCount = orders.filter(o => o.status === OrderStatus.DELIVERED).length;
  const finalOrdersCount = orders.filter(o => o.status === OrderStatus.COMPLETED).length;
  
  const totalRevenue = orders
    .filter(o => o.status === OrderStatus.APPROVED || o.status === OrderStatus.DELIVERED || o.status === OrderStatus.COMPLETED)
    .reduce((acc, curr) => acc + (curr.monthlyPrice * curr.months), 0);
  
  const activeCustomers = users.length;

  const filteredOrders = orders.filter(order => 
    order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.productName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Split orders based on status for the tabs
  const preliminaryList = filteredOrders.filter(o => o.status === OrderStatus.PENDING);
  const waitingFilesList = filteredOrders.filter(o => o.status === OrderStatus.WAITING_FOR_FILES);
  const readyShippingList = filteredOrders.filter(o => o.status === OrderStatus.READY_FOR_SHIPPING);
  const shippedList = filteredOrders.filter(o => o.status === OrderStatus.DELIVERED);
  // Final list now only includes COMPLETED (Received) orders
  const finalList = filteredOrders.filter(o => o.status === OrderStatus.COMPLETED);

  const filteredCustomers = users.filter(customer => 
    (customer.firstName + ' ' + customer.lastName).toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone1.includes(searchTerm) ||
    customer.ccpNumber.includes(searchTerm) ||
    customer.nin.includes(searchTerm)
  );

  const latinRegex = /^[A-Za-z\s]+$/;

  const handleViewChange = (view: 'dashboard' | 'approvals' | 'customers') => {
    setActiveView(view);
    localStorage.setItem('dz_admin_view', view);
    setIsSidebarOpen(false);
    setSearchTerm('');
  }

  // Handle Shipping Inputs
  const handleShippingInputChange = (orderId: string, field: 'company' | 'tracking', value: string) => {
    setShippingUpdates(prev => ({
      ...prev,
      [orderId]: {
        ...prev[orderId],
        [field]: value
      }
    }));
    // Clear error for this row if user starts typing
    if (shippingErrors[orderId]) {
      setShippingErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[orderId];
        return newErrors;
      });
    }
  };

  const handleSendOrder = (e: React.MouseEvent, order: Order) => {
    e.stopPropagation();
    
    // Get values from state only. Do NOT fallback to order.deliveryCompany as that is for files.
    // Ensure we start fresh for product shipping.
    const currentCompany = shippingUpdates[order.id]?.company || '';
    const currentTracking = shippingUpdates[order.id]?.tracking || '';

    // Validation: Mandatory fields
    if (!currentCompany.trim() || !currentTracking.trim()) {
      setShippingErrors(prev => ({ ...prev, [order.id]: true }));
      return;
    }

    // Proceed to update status with new delivery info
    onUpdateStatus(
      order.id, 
      OrderStatus.DELIVERED, 
      undefined, 
      { deliveryCompany: currentCompany, trackingNumber: currentTracking }
    );
  };

  const handleConfirmReceipt = (e: React.MouseEvent, order: Order) => {
    e.stopPropagation(); // Stop row click propagation
    setConfirmReceiptModal({ show: true, order });
  };

  const processReceiptConfirmation = () => {
    if (confirmReceiptModal.order) {
      onUpdateStatus(confirmReceiptModal.order.id, OrderStatus.COMPLETED);
      setConfirmReceiptModal({ show: false, order: null });
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB'); // DD/MM/YYYY
  };

  const timeAgo = (dateStr?: string) => {
    if (!dateStr) return 'غير معروف';
    const date = new Date(dateStr);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    let interval = seconds / 31536000;
    if (interval > 1) return `منذ ${Math.floor(interval)} سنة`;
    interval = seconds / 2592000;
    if (interval > 1) return `منذ ${Math.floor(interval)} شهر`;
    interval = seconds / 86400;
    if (interval > 1) return `منذ ${Math.floor(interval)} يوم`;
    interval = seconds / 3600;
    if (interval > 1) return `منذ ${Math.floor(interval)} ساعة`;
    interval = seconds / 60;
    if (interval > 1) return `منذ ${Math.floor(interval)} دقيقة`;
    return 'منذ ثواني';
  };

  const handleCopyTracking = (e: React.MouseEvent, tracking: string, id: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(tracking);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'firstName' || name === 'lastName') {
      if (value !== '' && !latinRegex.test(value)) {
        setFieldWarning({ field: name, msg: 'يرجى الكتابة بالأحرف اللاتينية فقط' });
        return; 
      } else {
        setFieldWarning(null);
      }
    }
    if (name === 'ccpKey' && value.length > 2) return;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fieldName: keyof typeof files) => {
    if (e.target.files && e.target.files[0]) {
      setFiles(prev => ({ ...prev, [fieldName]: e.target.files![0] }));
    }
  };

  const handleAddCustomerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('كلمة المرور غير متطابقة');
      return;
    }

    // Validation
    if (!latinRegex.test(formData.firstName) || !latinRegex.test(formData.lastName)) {
      setError('الاسم واللقب يجب أن يكونا بالأحرف اللاتينية فقط');
      return;
    }

    if (users.some(u => u.email === formData.email)) { setError('البريد الإلكتروني مسجل مسبقاً'); return; }
    if (users.some(u => u.phone1 === formData.phone1)) { setError('رقم الهاتف مسجل مسبقاً'); return; }
    if (users.some(u => u.ccpNumber === formData.ccpNumber)) { setError('رقم الحساب البريدي مسجل مسبقاً'); return; }
    if (users.some(u => u.nin === formData.nin)) { setError('رقم بطاقة التعريف مسجل مسبقاً'); return; }

    // Check files
    if (!files.idCardFront || !files.idCardBack || !files.chequeImage || !files.accountStatement) {
      setError('يرجى رفع جميع الوثائق المطلوبة');
      return;
    }

    const now = new Date().toISOString();
    const newUser: User = {
      ...formData,
      role: 'customer',
      registrationDate: now,
      lastLoginDate: now,
      idCardFront: files.idCardFront.name,
      idCardBack: files.idCardBack.name,
      chequeImage: files.chequeImage.name,
      accountStatement: files.accountStatement.name,
    };

    if (onAddUser) {
      onAddUser(newUser);
      setShowAddCustomer(false);
      setFormData(initialFormState);
      setFiles({
        idCardFront: null,
        idCardBack: null,
        chequeImage: null,
        accountStatement: null,
      });
    }
  };

  // Add Product Submit
  const handleAddProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onAddProduct) return;

    if (!newProduct.name || !newProduct.totalPrice || !newProduct.imageUrl) {
        // Simple validation
        return;
    }

    const months = parseInt(newProduct.months);
    const totalPrice = parseInt(newProduct.totalPrice);
    const monthlyPrice = Math.ceil(totalPrice / months);

    const product: Product = {
        id: Date.now().toString(),
        name: newProduct.name,
        brand: newProduct.brand,
        category: newProduct.category || 'عام',
        description: newProduct.description,
        totalPrice: totalPrice,
        plan: {
            months: months,
            monthlyPrice: monthlyPrice
        },
        features: newProduct.features.split(',').map(f => f.trim()).filter(f => f),
        media: [
            { type: MediaType.IMAGE, url: newProduct.imageUrl }
        ]
    };

    onAddProduct(product);
    setShowAddProduct(false);
    setNewProduct(initialProductState);
  };

  const handleOrderClick = (order: Order) => {
    // If order has a pending notification, clear it
    if (deliveryUpdates.includes(order.id)) {
        clearDeliveryUpdate(order.id);
    }

    const customer = users.find(u => u.phone1 === order.customerPhone) || null;
    setSelectedCustomer(customer);
    setSelectedOrder(order);
  };

  const handleCustomerClick = (customer: User) => {
    setSelectedCustomer(customer);
    setSelectedOrder(null);
  };

  const closeOrderDetails = () => {
    setSelectedOrder(null);
    setSelectedCustomer(null);
  };

  const openRejectModal = (orderId: string) => {
    setRejectionReason('');
    setRejectModal({ show: true, orderId });
  };

  const confirmRejection = () => {
    if (rejectModal.orderId) {
      // Clear notification if exists
      if (deliveryUpdates.includes(rejectModal.orderId)) {
        clearDeliveryUpdate(rejectModal.orderId);
      }

      onUpdateStatus(rejectModal.orderId, OrderStatus.REJECTED, rejectionReason);
      setRejectModal({ show: false, orderId: null });
      if (selectedOrder?.id === rejectModal.orderId) {
        closeOrderDetails();
      }
    }
  };

  // Helper to get image URL for mock files
  const getDocumentUrl = (filename?: string) => {
    if (!filename) return '';
    // If it's a real URL (in a real app), use it.
    if (filename.startsWith('http') || filename.startsWith('blob') || filename.startsWith('data')) return filename;
    
    // For MOCK demo only: Return a placeholder that looks like a document
    // In production, this would be a URL to the storage bucket
    return 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?auto=format&fit=crop&w=1000&q=80';
  }

  const handleViewImage = (title: string, filename?: string) => {
    if (!filename) return;
    const url = getDocumentUrl(filename);
    setViewImage({ url, title });
  }

  const renderFileInput = (label: string, name: keyof typeof files) => (
    <div className="mb-4">
      <label className="block text-sm font-bold text-gray-700 mb-2">
        {label} <span className="text-red-500">*</span>
      </label>
      <div className="relative border-2 border-dashed border-gray-300 rounded-xl p-4 text-center hover:bg-gray-50 transition-colors cursor-pointer group">
        <input 
          type="file" 
          accept="image/*"
          required
          onChange={(e) => handleFileChange(e, name)}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        <div className="flex flex-col items-center gap-2">
          {files[name] ? (
             <CheckCircle className="text-emerald-500" size={32} />
          ) : (
             <Upload className="text-gray-400 group-hover:text-emerald-500 transition-colors" size={32} />
          )}
          <span className={`text-sm ${files[name] ? 'text-emerald-600 font-bold' : 'text-gray-500'}`}>
            {files[name] ? files[name]?.name : 'اضغط لرفع الصورة'}
          </span>
        </div>
      </div>
    </div>
  );

  const SidebarItem = ({ id, icon: Icon, label }: { id: 'dashboard' | 'approvals' | 'customers', icon: any, label: string }) => (
    <button
      onClick={() => handleViewChange(id)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold ${
        activeView === id 
          ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' 
          : 'text-gray-500 hover:bg-gray-100'
      }`}
    >
      <Icon size={20} />
      <span>{label}</span>
    </button>
  );

  // Helper to render status text for All Transactions table
  const renderStatusText = (currentStatus: OrderStatus, step: 'preliminary' | 'waiting' | 'ready' | 'shipped') => {
    const isRejected = currentStatus === OrderStatus.REJECTED;
    if (isRejected) {
       return <span className="text-[10px] font-bold text-red-600 bg-red-50 px-2 py-1 rounded-md whitespace-nowrap">مرفوض</span>;
    }

    let isCompleted = false;
    let isCurrent = false;

    // Helper to check if status is within a set of "completed" statuses for this step
    const isStatusOneOf = (s: OrderStatus, list: OrderStatus[]) => list.includes(s);

    switch (step) {
       case 'preliminary':
          isCurrent = currentStatus === OrderStatus.PENDING;
          isCompleted = currentStatus !== OrderStatus.PENDING;
          break;
          
       case 'waiting':
          isCurrent = currentStatus === OrderStatus.WAITING_FOR_FILES;
          isCompleted = isStatusOneOf(currentStatus, [OrderStatus.READY_FOR_SHIPPING, OrderStatus.DELIVERED, OrderStatus.COMPLETED]);
          break;
          
       case 'ready':
          isCurrent = currentStatus === OrderStatus.READY_FOR_SHIPPING;
          isCompleted = isStatusOneOf(currentStatus, [OrderStatus.DELIVERED, OrderStatus.COMPLETED]);
          break;
          
       case 'shipped':
          isCurrent = currentStatus === OrderStatus.DELIVERED;
          isCompleted = currentStatus === OrderStatus.COMPLETED;
          break;
    }

    if (isCompleted) return <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-1 rounded-md whitespace-nowrap">مكتمل</span>;
    if (isCurrent) return <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded-md whitespace-nowrap animate-pulse">جاري</span>;
    return <span className="text-xs text-gray-300 font-bold">-</span>;
  };

  const hasWaitingFilesUpdates = deliveryUpdates.some(id => 
     orders.find(o => o.id === id)?.status === OrderStatus.WAITING_FOR_FILES
  );

  return (
    <div className="flex min-h-[80vh] gap-6 relative">
      <button 
        className="md:hidden fixed bottom-6 left-6 z-50 bg-emerald-600 text-white p-3 rounded-full shadow-lg"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      >
        {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      <div className={`
        fixed md:relative inset-y-0 right-0 z-40 w-64 bg-white border-l border-gray-200 transform transition-transform duration-300 ease-in-out md:translate-x-0 p-4 shadow-xl md:shadow-none md:bg-transparent md:border-none
        ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="mb-8 px-2">
           <h2 className="text-2xl font-extrabold text-gray-800">لوحة التحكم</h2>
           <p className="text-xs text-gray-400">الإصدار 1.0</p>
        </div>
        <div className="space-y-2">
          <SidebarItem id="dashboard" icon={LayoutDashboard} label="نظرة عامة" />
          <SidebarItem id="approvals" icon={FileCheck} label="الطلبات" />
          <SidebarItem id="customers" icon={Users} label="الزبائن" />
        </div>
      </div>

      <div className="flex-1 overflow-x-hidden">
        {/* Toast Notification for Updates */}
        {showUpdateToast && (
            <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-10 py-5 rounded-2xl shadow-2xl flex items-center gap-4 z-[60] animate-bounce-in border-2 border-indigo-400/50">
               <div className="bg-white/20 p-2 rounded-full">
                 <Bell className="text-yellow-300 animate-pulse" size={28} />
               </div>
               <span className="font-extrabold text-lg">يوجد تحديثات جديدة من الزبائن!</span>
            </div>
        )}

        {activeView === 'dashboard' && (
          <div className="animate-fadeIn space-y-6">
            {/* Header */}
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-extrabold text-gray-800">الرئيسية</h2>
                  <p className="text-gray-500 text-sm">مرحباً بك في لوحة الإدارة</p>
                </div>
                <div className="bg-emerald-100 text-emerald-700 p-3 rounded-full">
                  <LayoutDashboard size={24} />
                </div>
            </div>

            {/* Icon Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                
                {/* Order Management */}
                <button onClick={() => { handleViewChange('approvals'); setActiveApprovalTab('all_transactions'); }} className="bg-white aspect-square rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center gap-3 hover:shadow-lg transition-all group relative">
                    <div className="p-4 rounded-full bg-rose-50 text-rose-600 group-hover:scale-110 transition-transform">
                        <FileCheck size={40} />
                    </div>
                    {deliveryUpdates.length > 0 && (
                        <div className="absolute top-4 left-4 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse"></div>
                    )}
                    <span className="font-bold text-gray-700 text-lg">إدارة الطلبات</span>
                    <span className="text-xs font-bold text-gray-400">التحكم الكامل</span>
                </button>

                {/* Revenue */}
                <div className="bg-white aspect-square rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center gap-3 hover:shadow-lg transition-all cursor-default group">
                    <div className="p-4 rounded-full bg-blue-50 text-blue-600 group-hover:scale-110 transition-transform">
                        <BarChart3 size={40} />
                    </div>
                    <span className="font-bold text-gray-700 text-lg">الأرباح</span>
                    <span className="text-sm font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">{totalRevenue.toLocaleString()} دج</span>
                </div>

                {/* Customers */}
                <button onClick={() => handleViewChange('customers')} className="bg-white aspect-square rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center gap-3 hover:shadow-lg transition-all group">
                    <div className="p-4 rounded-full bg-purple-50 text-purple-600 group-hover:scale-110 transition-transform">
                        <Users size={40} />
                    </div>
                    <span className="font-bold text-gray-700 text-lg">الزبائن</span>
                    <span className="text-xs font-bold text-gray-400">{activeCustomers} مسجل</span>
                </button>
                
                {/* Add Product Button */}
                <button onClick={() => setShowAddProduct(true)} className="bg-white aspect-square rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center gap-3 hover:shadow-lg transition-all group">
                    <div className="p-4 rounded-full bg-orange-50 text-orange-600 group-hover:scale-110 transition-transform">
                        <ShoppingBag size={40} />
                    </div>
                    <div className="flex items-center gap-1">
                       <Plus size={16} className="text-gray-400" />
                       <span className="font-bold text-gray-700 text-lg">إضافة منتج</span>
                    </div>
                    <span className="text-xs font-bold text-gray-400">تحديث المتجر</span>
                </button>

            </div>
          </div>
        )}

        {/* ... (Existing Views for Approvals and Customers remain unchanged in rendering logic) ... */}
        {activeView === 'approvals' && (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden animate-fadeIn">
            {/* ... Content of Approvals View ... */}
            <div className="p-6 border-b border-gray-100">
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <button 
                    onClick={() => handleViewChange('dashboard')}
                    className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 sm:hidden"
                  >
                    <ArrowLeft size={20} />
                  </button>
                  <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                    <FileCheck className="text-emerald-600" size={24} />
                    إدارة الطلبات
                  </h3>
                </div>
                <div className="relative w-full sm:w-64">
                  <input 
                    type="text" 
                    placeholder="بحث باسم الزبون أو المنتج..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2 px-4 pr-10 text-sm focus:outline-none focus:border-emerald-500"
                  />
                  <Search className="absolute right-3 top-2.5 text-gray-400" size={16} />
                </div>
              </div>

              {/* Tabs as Icons Grid - Changed to grid-cols-3 for mobile */}
              <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-6 gap-2 mb-6">
                 {/* All Transactions */}
                 <button
                    onClick={() => setActiveApprovalTab('all_transactions')}
                    className={`flex flex-col items-center justify-center gap-2 p-2 rounded-2xl transition-all duration-200 border h-24 relative ${
                        activeApprovalTab === 'all_transactions' 
                        ? 'bg-slate-800 text-white shadow-lg shadow-slate-200 scale-105' 
                        : 'bg-white border-slate-100 text-slate-500 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                 >
                    <ListFilter size={24} className={activeApprovalTab === 'all_transactions' ? 'animate-pulse' : ''} />
                    <span className="text-xs font-bold">كل المعاملات</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${activeApprovalTab === 'all_transactions' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                        {totalOrders}
                    </span>
                 </button>

                 {/* Preliminary */}
                 <button
                    onClick={() => setActiveApprovalTab('preliminary')}
                    className={`flex flex-col items-center justify-center gap-2 p-2 rounded-2xl transition-all duration-200 border h-24 ${
                        activeApprovalTab === 'preliminary' 
                        ? 'bg-amber-500 text-white shadow-lg shadow-amber-200 scale-105' 
                        : 'bg-white border-amber-100 text-amber-500 hover:border-amber-300 hover:bg-amber-50'
                    }`}
                 >
                    <Clock size={24} />
                    <span className="text-xs font-bold">الموافقة الأولية</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${activeApprovalTab === 'preliminary' ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-600'}`}>
                        {pendingOrders}
                    </span>
                 </button>

                 {/* Waiting Files */}
                 <button
                    onClick={() => setActiveApprovalTab('waiting_files')}
                    className={`flex flex-col items-center justify-center gap-2 p-2 rounded-2xl transition-all duration-200 border h-24 relative ${
                        activeApprovalTab === 'waiting_files' 
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 scale-105' 
                        : 'bg-white border-blue-100 text-blue-600 hover:border-blue-300 hover:bg-blue-50'
                    }`}
                 >
                    <FileText size={24} />
                    {hasWaitingFilesUpdates && (
                        <div className="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-pulse"></div>
                    )}
                    <span className="text-xs font-bold">انتظار الملفات</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${activeApprovalTab === 'waiting_files' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-600'}`}>
                        {waitingFilesOrdersCount}
                    </span>
                 </button>

                 {/* Ready Shipping */}
                 <button
                    onClick={() => setActiveApprovalTab('ready_shipping')}
                    className={`flex flex-col items-center justify-center gap-2 p-2 rounded-2xl transition-all duration-200 border h-24 ${
                        activeApprovalTab === 'ready_shipping' 
                        ? 'bg-purple-600 text-white shadow-lg shadow-purple-200 scale-105' 
                        : 'bg-white border-purple-100 text-purple-600 hover:border-purple-300 hover:bg-purple-50'
                    }`}
                 >
                    <PackageCheck size={24} />
                    <span className="text-xs font-bold">جاهز للإرسال</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${activeApprovalTab === 'ready_shipping' ? 'bg-white/20 text-white' : 'bg-purple-100 text-purple-600'}`}>
                        {readyShippingOrdersCount}
                    </span>
                 </button>

                 {/* Shipped */}
                 <button
                    onClick={() => setActiveApprovalTab('shipped')}
                    className={`flex flex-col items-center justify-center gap-2 p-2 rounded-2xl transition-all duration-200 border h-24 ${
                        activeApprovalTab === 'shipped' 
                        ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-200 scale-105' 
                        : 'bg-white border-cyan-100 text-cyan-600 hover:border-cyan-300 hover:bg-cyan-50'
                    }`}
                 >
                    <Truck size={24} />
                    <span className="text-xs font-bold">تم الإرسال</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${activeApprovalTab === 'shipped' ? 'bg-white/20 text-white' : 'bg-cyan-100 text-cyan-600'}`}>
                        {shippedOrdersCount}
                    </span>
                 </button>

                 {/* Final/Archive */}
                 <button
                    onClick={() => setActiveApprovalTab('final')}
                    className={`flex flex-col items-center justify-center gap-2 p-2 rounded-2xl transition-all duration-200 border h-24 ${
                        activeApprovalTab === 'final' 
                        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 scale-105' 
                        : 'bg-white border-emerald-100 text-emerald-600 hover:border-emerald-300 hover:bg-emerald-50'
                    }`}
                 >
                    <Archive size={24} />
                    <span className="text-xs font-bold">الأرشيف</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${activeApprovalTab === 'final' ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-600'}`}>
                        {finalOrdersCount}
                    </span>
                 </button>
              </div>

              {activeApprovalTab === 'ready_shipping' && (
                  <div className="mt-4 flex justify-end">
                      <button 
                         onClick={() => window.print()} 
                         className="flex items-center gap-2 bg-gray-800 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-gray-900 shadow-md transition-transform active:scale-95"
                      >
                         <Printer size={16} />
                         <span>طباعة القائمة</span>
                      </button>
                  </div>
              )}

              {activeApprovalTab === 'shipped' && (
                  <div className="mt-4 flex justify-end">
                      <button 
                         onClick={() => window.print()} 
                         className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-blue-700 shadow-md transition-transform active:scale-95"
                      >
                         <Printer size={16} />
                         <span>طباعة للإرسال للبريد</span>
                      </button>
                  </div>
              )}
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm">
                <thead className="bg-gray-50 text-gray-500 font-medium">
                  {activeApprovalTab === 'all_transactions' ? (
                     <tr>
                        <th className="px-6 py-2 whitespace-nowrap">الاسم واللقب</th>
                        <th className="px-6 py-2 whitespace-nowrap">المنتج</th>
                        <th className="px-6 py-2 whitespace-nowrap">السعر</th>
                        <th className="px-6 py-2 whitespace-nowrap">سعر القسط</th>
                        <th className="px-6 py-2 whitespace-nowrap">عدد الأشهر</th>
                        <th className="px-6 py-2 whitespace-nowrap text-center">الموافقة الأولية</th>
                        <th className="px-6 py-2 whitespace-nowrap text-center">انتظار الملفات</th>
                        <th className="px-6 py-2 whitespace-nowrap text-center">جاهز للإرسال</th>
                        <th className="px-6 py-2 whitespace-nowrap text-center">تم الإرسال</th>
                     </tr>
                  ) : (
                    <tr>
                      <th className="px-6 py-2 whitespace-nowrap">الزبون</th>
                      <th className="px-6 py-2 whitespace-nowrap">المنتج</th>
                      <th className="px-6 py-2 whitespace-nowrap">سعر المنتج</th>
                      <th className="px-6 py-2 whitespace-nowrap">القسط الشهري</th>
                      <th className="px-6 py-2 whitespace-nowrap">عدد الأشهر</th>
                      {(activeApprovalTab === 'waiting_files' || activeApprovalTab === 'ready_shipping' || activeApprovalTab === 'shipped' || activeApprovalTab === 'final') && <th className="px-6 py-2 whitespace-nowrap text-center">معلومات الإرسال</th>}
                      <th className="px-6 py-2 whitespace-nowrap text-center">الحالة</th>
                      <th className="px-6 py-2 whitespace-nowrap text-center">الإجراءات</th>
                    </tr>
                  )}
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {activeApprovalTab === 'all_transactions' && filteredOrders.map(order => (
                       <tr key={order.id} onClick={() => handleOrderClick(order)} className="hover:bg-gray-50/80 transition-colors cursor-pointer">
                          <td className="px-6 py-2 whitespace-nowrap"><div className="font-bold text-gray-900">{order.customerName}</div></td>
                          <td className="px-6 py-2 whitespace-nowrap text-gray-700">{order.productName}</td>
                          <td className="px-6 py-2 whitespace-nowrap font-bold text-emerald-700">{(order.monthlyPrice * order.months).toLocaleString()} دج</td>
                          <td className="px-6 py-2 whitespace-nowrap font-medium">{order.monthlyPrice.toLocaleString()} دج</td>
                          <td className="px-6 py-2 whitespace-nowrap text-gray-600">{order.months}</td>
                          <td className="px-6 py-2 whitespace-nowrap text-center">{renderStatusText(order.status, 'preliminary')}</td>
                          <td className="px-6 py-2 whitespace-nowrap text-center">{renderStatusText(order.status, 'waiting')}</td>
                          <td className="px-6 py-2 whitespace-nowrap text-center">{renderStatusText(order.status, 'ready')}</td>
                          <td className="px-6 py-2 whitespace-nowrap text-center">{renderStatusText(order.status, 'shipped')}</td>
                       </tr>
                    ))}
                    
                    {activeApprovalTab === 'preliminary' && preliminaryList.map(order => (
                        <tr key={order.id} onClick={() => handleOrderClick(order)} className="hover:bg-gray-50/80 transition-colors cursor-pointer">
                             <td className="px-6 py-2 whitespace-nowrap"><div className="font-bold">{order.customerName}</div><div className="text-xs text-gray-500">{order.customerPhone}</div></td>
                             <td className="px-6 py-2 whitespace-nowrap">{order.productName}</td>
                             <td className="px-6 py-2 whitespace-nowrap font-bold text-emerald-700">{(order.monthlyPrice * order.months).toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap font-medium">{order.monthlyPrice.toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap text-gray-600">{order.months} أشهر</td>
                             <td className="px-6 py-2 whitespace-nowrap text-center"><span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-bold">{order.status}</span></td>
                             <td className="px-6 py-2 whitespace-nowrap">
                                <div className="flex justify-center gap-2">
                                  <button onClick={(e) => {e.stopPropagation(); onUpdateStatus(order.id, OrderStatus.WAITING_FOR_FILES)}} className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold">موافقة</button>
                                  <button onClick={(e) => {e.stopPropagation(); openRejectModal(order.id)}} className="px-3 py-1 bg-red-100 text-red-700 rounded-lg text-xs font-bold">رفض</button>
                                </div>
                             </td>
                        </tr>
                    ))}
                    {activeApprovalTab === 'waiting_files' && waitingFilesList.map(order => {
                        const hasUpdate = deliveryUpdates.includes(order.id);
                        return (
                        <tr key={order.id} onClick={() => handleOrderClick(order)} className={`hover:bg-gray-50/80 transition-colors cursor-pointer ${hasUpdate ? 'bg-blue-50/50 border-r-4 border-blue-500' : ''}`}>
                             <td className="px-6 py-2 whitespace-nowrap">
                                <div className="font-bold">{order.customerName}</div>
                                <div className="text-xs text-gray-500">{order.customerPhone}</div>
                                {hasUpdate && <span className="text-[10px] font-bold bg-red-500 text-white px-1.5 py-0.5 rounded-full inline-block mt-1 animate-pulse">تحديث جديد</span>}
                             </td>
                             <td className="px-6 py-2 whitespace-nowrap">{order.productName}</td>
                             <td className="px-6 py-2 whitespace-nowrap font-bold text-emerald-700">{(order.monthlyPrice * order.months).toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap font-medium">{order.monthlyPrice.toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap text-gray-600">{order.months} أشهر</td>
                             <td className="px-6 py-2 whitespace-nowrap text-center">
                                {order.deliveryCompany ? (
                                    <div className="flex flex-col gap-1 items-center">
                                        <div className="text-xs font-bold bg-gray-100 px-2 py-0.5 rounded text-gray-700">{order.deliveryCompany}</div>
                                        {order.trackingNumber && (
                                            <button onClick={(e) => handleCopyTracking(e, order.trackingNumber || '', order.id)} className={`flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded transition-all border ${copiedId === order.id ? 'text-green-600 bg-green-50 border-green-200' : 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 border-transparent hover:border-emerald-100'}`} title="نسخ رقم التتبع">
                                                {copiedId === order.id ? <CheckCircle size={10} /> : <Copy size={10} />}
                                                {order.trackingNumber}
                                            </button>
                                        )}
                                    </div>
                                ) : <span className="text-xs text-amber-600">انتظار...</span>}
                             </td>
                             <td className="px-6 py-2 whitespace-nowrap text-center"><span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-bold">{order.status}</span></td>
                             <td className="px-6 py-2 whitespace-nowrap">
                                <div className="flex justify-center gap-2">
                                  <button onClick={(e) => {
                                      e.stopPropagation(); 
                                      if (deliveryUpdates.includes(order.id)) clearDeliveryUpdate(order.id);
                                      onUpdateStatus(order.id, OrderStatus.READY_FOR_SHIPPING);
                                  }} className="px-3 py-1 bg-green-100 text-green-700 rounded-lg text-xs font-bold flex items-center gap-1"><CheckCircle size={12}/> قبول</button>
                                  <button onClick={(e) => {e.stopPropagation(); openRejectModal(order.id)}} className="px-3 py-1 bg-red-100 text-red-700 rounded-lg text-xs font-bold">رفض</button>
                                </div>
                             </td>
                        </tr>
                    )})}
                    {activeApprovalTab === 'ready_shipping' && readyShippingList.map(order => (
                         <tr key={order.id} onClick={() => handleOrderClick(order)} className="hover:bg-gray-50/80 transition-colors cursor-pointer">
                             <td className="px-6 py-2 whitespace-nowrap"><div className="font-bold">{order.customerName}</div><div className="text-xs text-gray-500">{order.customerPhone}</div></td>
                             <td className="px-6 py-2 whitespace-nowrap">{order.productName}</td>
                             <td className="px-6 py-2 whitespace-nowrap font-bold text-emerald-700">{(order.monthlyPrice * order.months).toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap font-medium">{order.monthlyPrice.toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap text-gray-600">{order.months} أشهر</td>
                             <td className="px-6 py-2 whitespace-nowrap">
                                <div className="flex flex-col gap-2 min-w-[200px]" onClick={(e) => e.stopPropagation()}>
                                   <select value={shippingUpdates[order.id]?.company || ''} onChange={(e) => handleShippingInputChange(order.id, 'company', e.target.value)} className={`w-full text-xs border rounded p-1.5 focus:outline-none focus:border-emerald-500 bg-white ${shippingErrors[order.id] && !shippingUpdates[order.id]?.company ? 'border-red-500 bg-red-50' : 'border-gray-200'}`}>
                                      <option value="">اختر شركة التوصيل</option>
                                      {DELIVERY_COMPANIES.map(company => <option key={company} value={company}>{company}</option>)}
                                   </select>
                                   <input type="text" placeholder="رقم التتبع (اجباري)" value={shippingUpdates[order.id]?.tracking || ''} onChange={(e) => handleShippingInputChange(order.id, 'tracking', e.target.value)} className={`w-full text-xs border rounded p-1.5 focus:outline-none focus:border-emerald-500 font-mono ${shippingErrors[order.id] && !shippingUpdates[order.id]?.tracking ? 'border-red-500 bg-red-50 placeholder-red-400' : 'border-gray-200'}`} />
                                </div>
                             </td>
                             <td className="px-6 py-2 whitespace-nowrap text-center"><span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold">{order.status}</span></td>
                             <td className="px-6 py-2 whitespace-nowrap">
                                <div className="flex justify-center gap-2">
                                  <button onClick={(e) => handleSendOrder(e, order)} className="px-4 py-1.5 bg-gray-800 text-white rounded-lg text-xs font-bold hover:bg-gray-900 flex items-center gap-1 shadow-lg shadow-gray-200"><Send size={12}/> ارسال</button>
                                </div>
                             </td>
                        </tr>
                    ))}
                    {activeApprovalTab === 'shipped' && shippedList.map(order => (
                         <tr key={order.id} onClick={() => handleOrderClick(order)} className="hover:bg-gray-50/80 transition-colors cursor-pointer">
                             <td className="px-6 py-2 whitespace-nowrap"><div className="font-bold">{order.customerName}</div><div className="text-xs text-gray-500">{order.customerPhone}</div></td>
                             <td className="px-6 py-2 whitespace-nowrap">{order.productName}</td>
                             <td className="px-6 py-2 whitespace-nowrap font-bold text-emerald-700">{(order.monthlyPrice * order.months).toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap font-medium">{order.monthlyPrice.toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap text-gray-600">{order.months} أشهر</td>
                             <td className="px-6 py-2 whitespace-nowrap text-center">
                                {order.shippingCompany ? (
                                    <div className="flex flex-col gap-1 items-center">
                                        <div className="text-xs font-bold bg-gray-100 px-2 py-0.5 rounded text-gray-700">{order.shippingCompany}</div>
                                        {order.shippingTrackingNumber && (
                                            <button onClick={(e) => handleCopyTracking(e, order.shippingTrackingNumber || '', order.id)} className={`flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded transition-all border ${copiedId === order.id ? 'text-green-600 bg-green-50 border-green-200' : 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 border-transparent hover:border-emerald-100'}`} title="نسخ رقم التتبع">
                                                {copiedId === order.id ? <CheckCircle size={10} /> : <Copy size={10} />}
                                                {order.shippingTrackingNumber}
                                            </button>
                                        )}
                                    </div>
                                ) : <span className="text-gray-400 text-xs">-</span>}
                             </td>
                             <td className="px-6 py-2 whitespace-nowrap text-center"><span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">{order.status}</span></td>
                             <td className="px-6 py-2 whitespace-nowrap text-center">
                                 <button onClick={(e) => handleConfirmReceipt(e, order)} className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 flex items-center justify-center gap-1 shadow-lg shadow-emerald-200 mx-auto transition-transform active:scale-95">
                                    <PackageCheck size={14} /> تم الوصول
                                 </button>
                             </td>
                        </tr>
                    ))}
                    {activeApprovalTab === 'final' && finalList.map(order => (
                         <tr key={order.id} onClick={() => handleOrderClick(order)} className="hover:bg-gray-50/80 transition-colors cursor-pointer">
                             <td className="px-6 py-2 whitespace-nowrap"><div className="font-bold">{order.customerName}</div><div className="text-xs text-gray-500">{order.customerPhone}</div></td>
                             <td className="px-6 py-2 whitespace-nowrap">{order.productName}</td>
                             <td className="px-6 py-2 whitespace-nowrap font-bold text-emerald-700">{(order.monthlyPrice * order.months).toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap font-medium">{order.monthlyPrice.toLocaleString()} دج</td>
                             <td className="px-6 py-2 whitespace-nowrap text-gray-600">{order.months} أشهر</td>
                             <td className="px-6 py-2 whitespace-nowrap text-center">
                                {order.shippingCompany ? (
                                    <div className="flex flex-col gap-1 items-center">
                                        <div className="text-xs font-bold bg-gray-100 px-2 py-0.5 rounded text-gray-700">{order.shippingCompany}</div>
                                        {order.shippingTrackingNumber && (
                                            <button onClick={(e) => handleCopyTracking(e, order.shippingTrackingNumber || '', order.id)} className={`flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded transition-all border ${copiedId === order.id ? 'text-green-600 bg-green-50 border-green-200' : 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 border-transparent hover:border-emerald-100'}`} title="نسخ رقم التتبع">
                                                {copiedId === order.id ? <CheckCircle size={10} /> : <Copy size={10} />}
                                                {order.shippingTrackingNumber}
                                            </button>
                                        )}
                                    </div>
                                ) : <span className="text-gray-400 text-xs">-</span>}
                             </td>
                             <td className="px-6 py-2 whitespace-nowrap text-center"><span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs font-bold">مكتمل</span></td>
                             <td className="px-6 py-2 whitespace-nowrap text-center text-gray-400"><Archive size={18} className="mx-auto text-gray-500" /></td>
                        </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeView === 'customers' && (
           <div className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden animate-fadeIn">
             <div className="p-6 border-b border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <button onClick={() => handleViewChange('dashboard')} className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 sm:hidden"><ArrowLeft size={20} /></button>
                  <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2"><Users className="text-purple-600" size={24} /> قائمة الزبائن</h3>
                </div>
                <div className="flex items-center gap-3 w-full sm:w-auto">
                   <div className="relative flex-1 sm:w-64">
                    <input type="text" placeholder="بحث باسم، هاتف، أو رقم حساب..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2 px-4 pr-10 text-sm focus:outline-none focus:border-purple-500" />
                    <Search className="absolute right-3 top-2.5 text-gray-400" size={16} />
                   </div>
                   <button onClick={() => setShowAddCustomer(true)} className="bg-purple-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-purple-700 flex items-center gap-2 shadow-lg shadow-purple-200 transition-transform active:scale-95">
                     <UserPlus size={18} /> <span className="hidden sm:inline">إضافة زبون</span>
                   </button>
                </div>
             </div>

             <div className="overflow-x-auto">
               <table className="w-full text-right text-sm">
                 <thead className="bg-gray-50 text-gray-500 font-medium">
                   <tr>
                     <th className="px-6 py-4 whitespace-nowrap">الزبون</th>
                     <th className="px-6 py-4 whitespace-nowrap">معلومات الاتصال</th>
                     <th className="px-6 py-4 whitespace-nowrap">تاريخ التسجيل</th>
                     <th className="px-6 py-4 whitespace-nowrap">آخر دخول</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-gray-100">
                    {filteredCustomers.map((customer, idx) => (
                      <tr key={idx} onClick={() => handleCustomerClick(customer)} className="hover:bg-gray-50/50 transition-colors cursor-pointer">
                        <td className="px-6 py-4 whitespace-nowrap">
                            <div className="font-bold text-gray-900">{customer.firstName} {customer.lastName}</div>
                            <div className="text-xs text-gray-500">{customer.wilaya}, {customer.baladyia}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex flex-col gap-1">
                               <a href={`tel:${customer.phone1}`} onClick={(e) => e.stopPropagation()} className="font-mono text-gray-700 font-bold hover:text-emerald-600 transition-colors flex items-center gap-1 w-fit">
                                  {customer.phone1}
                               </a>
                               <a href={`mailto:${customer.email}`} onClick={(e) => e.stopPropagation()} className="text-xs text-gray-400 font-mono hover:text-emerald-600 transition-colors w-fit">
                                  {customer.email}
                               </a>
                            </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-600 text-xs font-medium font-mono">{formatDate(customer.registrationDate)}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                            <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-bold">
                              {timeAgo(customer.lastLoginDate)}
                            </span>
                        </td>
                      </tr>
                    ))}
                    {filteredCustomers.length === 0 && (
                        <tr><td colSpan={5} className="px-6 py-8 text-center text-gray-400">لا يوجد زبائن مطابقين للبحث</td></tr>
                    )}
                 </tbody>
               </table>
             </div>
           </div>
        )}
      </div>

      {/* MODAL: ADD CUSTOMER */}
      {showAddCustomer && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-start p-4">
             <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl my-8 relative animate-scaleUp">
                 <button onClick={() => setShowAddCustomer(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 bg-gray-100 p-2 rounded-full transition-colors z-10"><X size={20} /></button>
                 <div className="bg-purple-600 p-6 rounded-t-3xl text-white">
                    <h2 className="text-2xl font-bold flex items-center gap-2"><UserPlus size={24} /> إضافة زبون جديد</h2>
                 </div>
                 <div className="p-8">
                     {error && (
                        <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-6 text-sm font-bold text-center border border-red-100 flex items-center justify-center gap-2"><AlertCircle size={16} /> {error}</div>
                     )}
                     <form onSubmit={handleAddCustomerSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">الاسم</label>
                              <input type="text" name="firstName" value={formData.firstName} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required dir="ltr" />
                              {fieldWarning?.field === 'firstName' && <p className="text-red-500 text-xs mt-1">{fieldWarning.msg}</p>}
                           </div>
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">اللقب</label>
                              <input type="text" name="lastName" value={formData.lastName} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required dir="ltr" />
                              {fieldWarning?.field === 'lastName' && <p className="text-red-500 text-xs mt-1">{fieldWarning.msg}</p>}
                           </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">تاريخ الميلاد</label>
                              <input type="date" name="birthDate" value={formData.birthDate} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required />
                           </div>
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">الهاتف</label>
                              <input type="tel" name="phone1" value={formData.phone1} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required />
                           </div>
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-2">البريد الإلكتروني</label>
                            <input type="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                               <label className="block text-sm font-bold text-gray-700 mb-2">الولاية</label>
                               <select name="wilaya" value={formData.wilaya} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none">
                                  {ALGERIA_WILAYAS.map(w => <option key={w} value={w}>{w}</option>)}
                               </select>
                            </div>
                            <div>
                               <label className="block text-sm font-bold text-gray-700 mb-2">البلدية</label>
                               <input type="text" name="baladyia" value={formData.baladyia} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required />
                            </div>
                        </div>
                        <div>
                           <label className="block text-sm font-bold text-gray-700 mb-2">العنوان</label>
                           <input type="text" name="address" value={formData.address} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                               <label className="block text-sm font-bold text-gray-700 mb-2">رقم CCP</label>
                               <div className="flex gap-2">
                                  <input type="number" name="ccpNumber" value={formData.ccpNumber} onChange={handleInputChange} className="flex-1 border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required />
                                  <input type="number" name="ccpKey" value={formData.ccpKey} onChange={handleInputChange} className="w-16 border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none text-center" required placeholder="Clé" />
                               </div>
                            </div>
                            <div>
                               <label className="block text-sm font-bold text-gray-700 mb-2">رقم بطاقة التعريف</label>
                               <input type="number" name="nin" value={formData.nin} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required />
                            </div>
                        </div>
                        <div className="border-t pt-4">
                            <h4 className="font-bold text-gray-800 mb-4">الملفات المرفقة</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                {renderFileInput('بطاقة التعريف (أمام)', 'idCardFront')}
                                {renderFileInput('بطاقة التعريف (خلف)', 'idCardBack')}
                                {renderFileInput('صك بريدي مشطوب', 'chequeImage')}
                                {renderFileInput('كشف الحساب', 'accountStatement')}
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                            <div>
                               <label className="block text-sm font-bold text-gray-700 mb-2">كلمة المرور</label>
                               <input type="password" name="password" value={formData.password} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required minLength={6} />
                            </div>
                            <div>
                               <label className="block text-sm font-bold text-gray-700 mb-2">تأكيد كلمة المرور</label>
                               <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleInputChange} className="w-full border p-2.5 rounded-xl bg-gray-50 focus:bg-white focus:border-purple-500 outline-none" required minLength={6} />
                            </div>
                        </div>
                        <div className="pt-4 flex gap-3">
                           <Button type="submit" fullWidth className="bg-purple-600 hover:bg-purple-700 shadow-purple-200">حفظ وإضافة الزبون</Button>
                           <Button type="button" variant="secondary" onClick={() => setShowAddCustomer(false)}>إلغاء</Button>
                        </div>
                     </form>
                 </div>
             </div>
        </div>
      )}

      {/* MODAL: ADD PRODUCT */}
      {showAddProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-start p-4">
             <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl my-8 relative animate-scaleUp">
                 <button onClick={() => setShowAddProduct(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 bg-gray-100 p-2 rounded-full transition-colors z-10"><X size={20} /></button>
                 <div className="bg-orange-500 p-6 rounded-t-3xl text-white">
                    <h2 className="text-2xl font-bold flex items-center gap-2"><ShoppingBag size={24} /> إضافة منتج جديد</h2>
                 </div>
                 <div className="p-8">
                     <form onSubmit={handleAddProductSubmit} className="space-y-4">
                        <div>
                           <label className="block text-sm font-bold text-gray-700 mb-2">اسم المنتج</label>
                           <input 
                              type="text" 
                              value={newProduct.name} 
                              onChange={(e) => setNewProduct({...newProduct, name: e.target.value})} 
                              className="w-full border p-3 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none" 
                              required 
                              placeholder="مثال: تلفاز سامسونج 55 بوصة"
                           />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">الماركة</label>
                              <input 
                                 type="text" 
                                 value={newProduct.brand} 
                                 onChange={(e) => setNewProduct({...newProduct, brand: e.target.value})} 
                                 className="w-full border p-3 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none" 
                                 placeholder="Samsung"
                              />
                           </div>
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">الفئة</label>
                              <input 
                                 type="text" 
                                 value={newProduct.category} 
                                 onChange={(e) => setNewProduct({...newProduct, category: e.target.value})} 
                                 className="w-full border p-3 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none" 
                                 placeholder="تلفاز"
                              />
                           </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">السعر الإجمالي</label>
                              <div className="relative">
                                 <input 
                                    type="number" 
                                    value={newProduct.totalPrice} 
                                    onChange={(e) => setNewProduct({...newProduct, totalPrice: e.target.value})} 
                                    className="w-full border p-3 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none pl-10" 
                                    required 
                                    placeholder="0"
                                 />
                                 <span className="absolute left-3 top-3 text-gray-400 text-xs font-bold">دج</span>
                              </div>
                           </div>
                           <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">مدة التقسيط</label>
                              <select 
                                 value={newProduct.months} 
                                 onChange={(e) => setNewProduct({...newProduct, months: e.target.value})} 
                                 className="w-full border p-3 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none"
                              >
                                 <option value="12">12 شهر</option>
                                 <option value="18">18 شهر</option>
                                 <option value="24">24 شهر</option>
                              </select>
                           </div>
                        </div>

                        <div>
                           <label className="block text-sm font-bold text-gray-700 mb-2">الوصف</label>
                           <textarea 
                              value={newProduct.description} 
                              onChange={(e) => setNewProduct({...newProduct, description: e.target.value})} 
                              className="w-full border p-3 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none h-24 resize-none" 
                              placeholder="وصف مختصر للمنتج..."
                           />
                        </div>

                        <div>
                           <label className="block text-sm font-bold text-gray-700 mb-2">المميزات (افصل بفاصلة)</label>
                           <input 
                              type="text" 
                              value={newProduct.features} 
                              onChange={(e) => setNewProduct({...newProduct, features: e.target.value})} 
                              className="w-full border p-3 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none" 
                              placeholder="4K, Smart TV, HDMI..."
                           />
                        </div>

                        <div>
                           <label className="block text-sm font-bold text-gray-700 mb-2">رابط الصورة</label>
                           <div className="relative">
                              <Image className="absolute right-3 top-3.5 text-gray-400" size={20} />
                              <input 
                                 type="text" 
                                 value={newProduct.imageUrl} 
                                 onChange={(e) => setNewProduct({...newProduct, imageUrl: e.target.value})} 
                                 className="w-full border p-3 pr-10 rounded-xl bg-gray-50 focus:bg-white focus:border-orange-500 outline-none ltr text-left" 
                                 placeholder="https://example.com/image.jpg"
                                 required
                                 dir="ltr"
                              />
                           </div>
                           <p className="text-xs text-gray-400 mt-1">يرجى إدخال رابط صورة صالح</p>
                        </div>

                        <div className="pt-4 flex gap-3">
                           <Button type="submit" fullWidth className="bg-orange-600 hover:bg-orange-700 shadow-orange-200">إضافة المنتج</Button>
                           <Button type="button" variant="secondary" onClick={() => setShowAddProduct(false)}>إلغاء</Button>
                        </div>
                     </form>
                 </div>
             </div>
        </div>
      )}

      {/* MODAL: ORDER DETAILS & FULL CUSTOMER INFO */}
      {selectedCustomer && (
         <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-center p-4" onClick={closeOrderDetails}>
            <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden animate-scaleUp relative flex flex-col max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
                <button onClick={closeOrderDetails} className="absolute top-4 right-4 bg-gray-100 p-2 rounded-full hover:bg-gray-200 z-10"><X size={20}/></button>
                
                {/* Scrollable Container */}
                <div className="overflow-y-auto flex-1 flex flex-col md:flex-row">
                    {/* Left: Product & Status */}
                    <div className="w-full md:w-1/3 bg-gray-50 p-6 border-l border-gray-100 flex flex-col items-center text-center">
                        {selectedOrder ? (
                            <>
                                <img src={selectedOrder.productImage} alt="" className="w-32 h-32 rounded-xl object-cover shadow-md mb-4" />
                                <h3 className="font-bold text-gray-900 mb-1 text-lg">{selectedOrder.productName}</h3>
                                <p className="text-emerald-600 font-extrabold text-xl mb-6">{selectedOrder.monthlyPrice.toLocaleString()} دج / شهر</p>
                                
                                <div className="w-full grid grid-cols-3 gap-2 mb-6">
                                    <div className="bg-white p-2 rounded-xl border border-gray-200 flex flex-col items-center justify-center shadow-sm">
                                        <span className="text-[10px] text-gray-400 mb-1">الحالة</span>
                                        <span className="font-bold text-emerald-600 text-xs text-center leading-tight">{selectedOrder.status}</span>
                                    </div>
                                    <div className="bg-white p-2 rounded-xl border border-gray-200 flex flex-col items-center justify-center shadow-sm">
                                        <span className="text-[10px] text-gray-400 mb-1">المدة</span>
                                        <span className="font-bold text-gray-800 text-xs">{selectedOrder.months} أشهر</span>
                                    </div>
                                    <div className="bg-white p-2 rounded-xl border border-gray-200 flex flex-col items-center justify-center shadow-sm">
                                        <span className="text-[10px] text-gray-400 mb-1">التاريخ</span>
                                        <span className="font-bold text-gray-800 text-[10px]" dir="ltr">{selectedOrder.date}</span>
                                    </div>
                                </div>
                                
                                {/* Action Buttons based on Status */}
                                <div className="mt-2 w-full">
                                    {selectedOrder.status === OrderStatus.PENDING && (
                                    <div className="flex flex-col gap-3">
                                        <Button fullWidth onClick={() => { onUpdateStatus(selectedOrder.id, OrderStatus.WAITING_FOR_FILES); closeOrderDetails(); }}><CheckCircle size={18} /> قبول مبدئي</Button>
                                        <Button fullWidth variant="danger" onClick={() => { openRejectModal(selectedOrder.id); closeOrderDetails(); }}><XCircle size={18} /> رفض الطلب</Button>
                                    </div>
                                    )}
                                    {selectedOrder.status === OrderStatus.WAITING_FOR_FILES && (
                                        <div>
                                            <div className="bg-amber-50 p-3 rounded-lg border border-amber-100 text-amber-800 text-sm mb-3 text-right">
                                            <strong>حالة الملف:</strong> في انتظار استلام الملف الورقي.
                                            {selectedOrder.deliveryCompany && (
                                                <div className="mt-1 border-t border-amber-200 pt-1">يتم الإرسال عبر: <strong>{selectedOrder.deliveryCompany}</strong><br/>رقم التتبع: <strong className="font-mono">{selectedOrder.trackingNumber}</strong></div>
                                            )}
                                            </div>
                                            <Button fullWidth onClick={() => { onUpdateStatus(selectedOrder.id, OrderStatus.READY_FOR_SHIPPING); closeOrderDetails(); }} className="bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200"><FolderCheck size={18} /> تأكيد استلام الملف</Button>
                                        </div>
                                    )}
                                </div>
                            </>
                        ) : (
                            <>
                                <div className="w-32 h-32 rounded-full bg-purple-100 flex items-center justify-center mb-4 shadow-inner text-purple-600 mt-8">
                                    <UserIcon size={64} />
                                </div>
                                <h3 className="font-bold text-gray-900 mb-1 text-lg">{selectedCustomer.firstName} {selectedCustomer.lastName}</h3>
                                <p className="text-gray-500 font-mono mb-6">{selectedCustomer.phone1}</p>
                                
                                <div className="w-full bg-white p-4 rounded-xl border border-gray-200 shadow-sm text-sm">
                                    <div className="flex justify-between mb-2 border-b border-gray-100 pb-2">
                                    <span className="text-gray-500">تاريخ التسجيل</span>
                                    <span className="font-bold" dir="ltr">{formatDate(selectedCustomer.registrationDate)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                    <span className="text-gray-500">آخر دخول</span>
                                    <span className="font-bold">{timeAgo(selectedCustomer.lastLoginDate)}</span>
                                    </div>
                                </div>
                            </>
                        )}
                    </div>

                    {/* Right: Full Customer Details */}
                    <div className="flex-1 p-5 bg-white">
                        <div className="flex items-center justify-between mb-4 border-b border-gray-100 pb-2">
                             <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                                <Users size={20} className="text-emerald-600" /> معلومات الزبون
                            </h3>
                        </div>
                        
                        {/* Info Grid - Compact Layout */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4 text-sm">
                            
                            {/* Personal Card */}
                            <div className="bg-gray-50 rounded-xl p-3 border border-gray-100">
                                <h4 className="font-bold text-gray-700 mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                                    <UserIcon size={14} className="text-emerald-500" /> الشخصية
                                </h4>
                                <div className="space-y-2">
                                    <div className="flex justify-between">
                                        <span className="text-gray-400 text-xs">الاسم الكامل</span>
                                        <span className="font-bold text-gray-800">{selectedCustomer.firstName} {selectedCustomer.lastName}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-400 text-xs">تاريخ الميلاد</span>
                                        <span className="font-medium text-gray-700" dir="ltr">{formatDate(selectedCustomer.birthDate)}</span>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span className="text-gray-400 text-xs">رقم التعريف</span>
                                        <span className="font-mono text-xs bg-white px-2 py-0.5 rounded border border-gray-200 text-gray-600">{selectedCustomer.nin}</span>
                                    </div>
                                </div>
                            </div>

                            {/* Contact Card */}
                            <div className="bg-gray-50 rounded-xl p-3 border border-gray-100">
                                <h4 className="font-bold text-gray-700 mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                                    <Phone size={14} className="text-emerald-500" /> الاتصال
                                </h4>
                                <div className="space-y-2">
                                    <div className="flex justify-between">
                                        <span className="text-gray-400 text-xs">الهاتف</span>
                                        <a href={`tel:${selectedCustomer.phone1}`} className="font-bold text-gray-800 font-mono hover:text-emerald-600 transition-colors" dir="ltr">
                                            {selectedCustomer.phone1}
                                        </a>
                                    </div>
                                    {selectedCustomer.phone2 && (
                                        <div className="flex justify-between">
                                            <span className="text-gray-400 text-xs">هاتف 2</span>
                                            <a href={`tel:${selectedCustomer.phone2}`} className="font-medium text-gray-700 font-mono hover:text-emerald-600 transition-colors" dir="ltr">
                                                {selectedCustomer.phone2}
                                            </a>
                                        </div>
                                    )}
                                    <div className="flex flex-col mt-1">
                                        <span className="text-gray-400 text-xs mb-0.5">البريد الإلكتروني</span>
                                        <a href={`mailto:${selectedCustomer.email}`} className="font-medium text-gray-700 text-xs truncate hover:text-emerald-600 transition-colors" title={selectedCustomer.email}>
                                            {selectedCustomer.email}
                                        </a>
                                    </div>
                                </div>
                            </div>

                             {/* Location Card */}
                             <div className="bg-gray-50 rounded-xl p-3 border border-gray-100">
                                <h4 className="font-bold text-gray-700 mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                                    <MapPin size={14} className="text-emerald-500" /> العنوان
                                </h4>
                                <div className="space-y-1">
                                    <div className="font-bold text-gray-800 text-sm">{selectedCustomer.wilaya} - {selectedCustomer.baladyia}</div>
                                    <div className="text-xs text-gray-600 leading-snug">{selectedCustomer.address}</div>
                                </div>
                            </div>

                            {/* Financial Card */}
                            <div className="bg-gray-50 rounded-xl p-3 border border-gray-100">
                                <h4 className="font-bold text-gray-700 mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                                    <CreditCard size={14} className="text-emerald-500" /> المالية
                                </h4>
                                <div>
                                    <div className="flex items-center justify-between mb-2">
                                        <span className="text-gray-400 text-xs">CCP</span>
                                        <div className="flex items-center gap-1 font-mono font-bold text-gray-800 bg-white px-2 py-0.5 rounded border border-gray-200 text-sm">
                                            <span>{selectedCustomer.ccpNumber}</span>
                                            <span className="text-gray-300">/</span>
                                            <span className="text-emerald-600">{selectedCustomer.ccpKey}</span>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-2 text-xs">
                                        <div>
                                            <span className="text-gray-400 block">التسجيل</span>
                                            <span className="font-medium" dir="ltr">{formatDate(selectedCustomer.registrationDate)}</span>
                                        </div>
                                         <div>
                                            <span className="text-gray-400 block">آخر دخول</span>
                                            <span className="font-medium">{timeAgo(selectedCustomer.lastLoginDate)}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Documents Section - Compact */}
                        <div className="mt-4 pt-4 border-t border-gray-100">
                            <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2 text-sm">
                                <FolderOpen size={16} className="text-emerald-600" /> الوثائق
                            </h4>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                {[
                                    { label: 'بطاقة (أمام)', key: 'idCardFront' },
                                    { label: 'بطاقة (خلف)', key: 'idCardBack' },
                                    { label: 'صك بريدي', key: 'chequeImage' },
                                    { label: 'كشف الحساب', key: 'accountStatement' }
                                ].map((doc, i) => {
                                    const fileName = (selectedCustomer as any)[doc.key];
                                    return (
                                        <div 
                                            key={i} 
                                            onClick={() => handleViewImage(doc.label, fileName)}
                                            className="bg-white rounded-lg p-2 border border-gray-200 flex flex-col items-center gap-2 hover:border-emerald-400 hover:shadow-sm cursor-pointer transition-all group relative overflow-hidden"
                                        >
                                            <div className="absolute top-0 right-0 p-1 bg-emerald-50 text-emerald-600 rounded-bl-lg opacity-0 group-hover:opacity-100 transition-opacity">
                                                <ZoomIn size={12} />
                                            </div>
                                            <div className="bg-gray-50 p-2 rounded-full">
                                                <Eye className="text-gray-400 group-hover:text-emerald-600" size={16} />
                                            </div>
                                            <p className="font-bold text-xs text-gray-700 text-center">{doc.label}</p>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      )}

      {/* MODAL: IMAGE VIEWER */}
      {viewImage && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex flex-col animate-fadeIn" onClick={() => setViewImage(null)}>
            {/* Header */}
            <div className="flex items-center justify-between p-4 text-white bg-black/50 backdrop-blur-md absolute top-0 left-0 right-0 z-10">
                <h3 className="font-bold text-lg">{viewImage.title}</h3>
                <button onClick={() => setViewImage(null)} className="p-2 hover:bg-white/20 rounded-full transition-colors">
                    <X size={24} />
                </button>
            </div>
            
            {/* Image Container */}
            <div className="flex-1 flex items-center justify-center p-4 overflow-hidden">
                <img 
                    src={viewImage.url} 
                    alt={viewImage.title} 
                    className="max-w-full max-h-full object-contain shadow-2xl rounded-lg"
                    onClick={(e) => e.stopPropagation()} 
                />
            </div>
            
            <div className="text-center text-gray-400 text-sm pb-4">
                اضغط في أي مكان للإغلاق
            </div>
        </div>
      )}

      {/* MODAL: REJECT CONFIRMATION */}
      {rejectModal.show && (
         <div className="fixed inset-0 z-[60] overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-center p-4">
            <div className="bg-white w-full max-w-md rounded-2xl shadow-xl p-6 animate-scaleUp">
               <h3 className="text-xl font-bold text-red-600 mb-4 flex items-center gap-2"><AlertCircle size={24} /> تأكيد رفض الطلب</h3>
               <p className="text-gray-600 mb-4 text-sm">هل أنت متأكد من رفض هذا الطلب؟ يرجى تحديد سبب الرفض لإبلاغ الزبون.</p>
               <textarea value={rejectionReason} onChange={(e) => setRejectionReason(e.target.value)} placeholder="سبب الرفض (مثال: كشف الراتب غير كافي...)" className="w-full border border-gray-300 rounded-xl p-3 text-sm focus:outline-none focus:border-red-500 min-h-[100px] mb-4"></textarea>
               <div className="flex gap-3">
                  <Button fullWidth variant="danger" onClick={confirmRejection}>تأكيد الرفض</Button>
                  <Button fullWidth variant="secondary" onClick={() => setRejectModal({ show: false, orderId: null })}>إلغاء</Button>
               </div>
            </div>
         </div>
      )}

      {/* MODAL: CONFIRM RECEIPT */}
      {confirmReceiptModal.show && confirmReceiptModal.order && (
        <div className="fixed inset-0 z-[60] overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl p-6 animate-scaleUp">
              <h3 className="text-xl font-bold text-emerald-600 mb-4 flex items-center gap-2"><PackageCheck size={24} /> تأكيد استلام الطلب</h3>
              <p className="text-gray-600 mb-6 text-sm leading-relaxed">
                هل أنت متأكد من أن الزبون <strong>{confirmReceiptModal.order.customerName}</strong> قد استلم الطلب بنجاح؟
                <br/>
                سيتم نقل الطلب إلى القائمة النهائية (الأرشيف).
              </p>
              <div className="flex gap-3">
                <Button fullWidth onClick={processReceiptConfirmation} className="bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200">نعم، تم الاستلام</Button>
                <Button fullWidth variant="secondary" onClick={() => setConfirmReceiptModal({ show: false, order: null })}>إلغاء</Button>
              </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
